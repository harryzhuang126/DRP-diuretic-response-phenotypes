# DRP 利尿应答表型与预后研究 — 分析代码包

对应稿件：利尿应答表型与机械通气患者预后关系（中华重症医学电子杂志，修回中）

## 文件清单

| 文件 | 说明 |
|---|---|
| `SAP_v1.1_freeze.md` | 统计分析计划（冻结版 v1.1） |
| `data_dictionary.md` | 分析数据集数据字典与 itemid 映射 |
| `build_sofa_pre.py` | SOFA 重算（全部使用 t0 前 24 h 数据；含尿量 itemid 复现验证） |
| `R4_cov9_locked.R` | 主分析（9 协变量版，修回第一轮锁定结果） |
| `R6_sofapre_rerun.R` | 主分析全套重跑（sofa_pre 版；含宽窗口 9 协变量、剂量 IPW、表型 GPS-IPW、连续 UO24+FB24 同模分析） |
| `build_lm_core.py` | 界标队列核心变量构建（含 ICD 编码规则：脓毒症/心衰/ESRD/肝硬化） |
| `build_lm_cohort.py` | 界标分析队列组装（L=t0+30 h） |
| `build_lm_sofa2.py` | 界标队列 SOFA 构建（含原规则逆向工程验证） |
| `landmark_models.R` / `landmark_models_v2.R` | 界标分析模型（原版 / sofa_pre 版） |

## 环境

- Python ≥3.10：pandas、numpy
- R 4.6.1：base、survival、nnet

## 数据

MIMIC-IV v3.1（需 PhysioNet 授权后自行提取）；本包不含任何患者级数据。

## 运行顺序

1. 按 `data_dictionary.md` 从 MIMIC-IV 提取原始事件表（labevents/chartevents/inputevents/outputevents/procedureevents/diagnoses_icd）
2. `python build_sofa_pre.py` → 生成含 sofa_pre 的增强队列
3. `Rscript R6_sofapre_rerun.R` → 主分析全套结果
4. `python build_lm_core.py && python build_lm_cohort.py` → 界标队列
5. `Rscript landmark_models_v2.R` → 界标分析结果
