# -*- coding: utf-8 -*-
"""SOFA reconstruction v2 for landmark cohort using reverse-engineered original rules.
Rules (validated on 692-case main cohort):
- plt_min: min Platelet(51265) in [t0-24h, t0]            -> exact
- bili_max: max Bili(50885) in [t0-24h, t0]               -> exact
- po2_min: min pO2(50821) in [t0-24h, t0]                 -> exact
- fio2_bg: max lab-FiO2(50816) in [t0-24h, t0]            -> exact (274/692 covered)
- pf = po2_min / (fio2_bg/100); resp = rule(pf); NaN counted missing
- gcs_min: min over charttime of complete-triplet sum (220739+223900+223901) [t0-24h,t0]
- vaso: norepi/epi/vasopressin/phenylephrine/dopamine/epi2/angiotensin overlapping [t0-24h, t0+24h] -> cardio 3
- inotrope: dobutamine/milrinone overlap [t0-24h, t0+24h] -> cardio 2 (if no vaso)
- cardio else 0 (MAP not used in original)
- renal: max(rule(cr_baseline), 3 if uo24<500mL else 0)   -> exact
- sofa_total = sum of 6 components with NaN->0; sofa_missing_n = number of NaN components
"""
import pandas as pd, numpy as np
from pathlib import Path

LM = Path(r'C:\Users\Administrator\Documents\kimi\workspace\revise_task\landmark')
EXT = Path(r'C:\Users\Administrator\Documents\kimi\workspace\DRP_weaning\extraction')

core = pd.read_csv(LM / 'lm_core.csv', parse_dates=['t0'])
ref = pd.read_csv(EXT / 'analysis_cohort_full.csv')

lab = pd.read_csv(LM / 'lm_labevents.csv', parse_dates=['charttime']).dropna(subset=['valuenum'])
m = lab.merge(core[['subject_id','stay_id','t0']].drop_duplicates(), on='subject_id')
w = m[(m.charttime >= m.t0 - pd.Timedelta(hours=24)) & (m.charttime <= m.t0)]
def agg(ids, fn, name):
    d = w[w.itemid.isin(ids)]
    return getattr(d.groupby('stay_id')['valuenum'], fn)().rename(name)

out = core[['stay_id']].copy()
for g in [agg([51265],'min','plt_min'), agg([50885],'max','bili_max'),
          agg([50912],'max','cr_win_max'), agg([50821],'min','po2_min')]:
    out = out.merge(g, on='stay_id', how='left')

# FiO2 (50816) max in [t0-24h, t0]
f5 = pd.read_csv(LM / 'lm_fio2_o2_labs.csv', header=None, names=['subject_id','charttime','valuenum'], parse_dates=['charttime'])
f5['valuenum'] = pd.to_numeric(f5['valuenum'], errors='coerce')
f5 = f5.dropna(subset=['valuenum'])
f5 = f5[(f5.valuenum>=20)&(f5.valuenum<=100)]
fm = f5.merge(core[['subject_id','stay_id','t0']].drop_duplicates(), on='subject_id')
fm = fm[(fm.charttime >= fm.t0 - pd.Timedelta(hours=24)) & (fm.charttime <= fm.t0)]
out = out.merge(fm.groupby('stay_id')['valuenum'].max().rename('fio2_bg'), on='stay_id', how='left')

# GCS: complete-triplet min sum
ce = pd.read_csv(LM / 'lm_chartevents_awk.csv', parse_dates=['charttime'])
gcs = ce[ce.itemid.isin([220739,223900,223901])].dropna(subset=['valuenum'])
g = gcs.drop(columns=['stay_id']).merge(core[['subject_id','stay_id','t0']].drop_duplicates(), on='subject_id')
g = g[(g.charttime >= g.t0 - pd.Timedelta(hours=24)) & (g.charttime <= g.t0)]
piv = g.pivot_table(index=['stay_id','charttime'], columns='itemid', values='valuenum', aggfunc='min')
piv['gcs_sum'] = piv.sum(axis=1, min_count=3)
out = out.merge(piv.groupby('stay_id')['gcs_sum'].min().rename('gcs_min'), on='stay_id', how='left')

# vaso / inotrope: overlap [t0-24h, t0+24h]
ie = pd.read_csv(LM / 'lm_inputevents.csv', parse_dates=['starttime','endtime'])
VASO = [221906,221289,222315,221749,221662,229617,229709,229764]
INO = [221653,221986]
vv = ie.merge(core[['stay_id','t0']], on='stay_id')
ov = vv[(vv.endtime >= vv.t0 - pd.Timedelta(hours=24)) & (vv.starttime <= vv.t0 + pd.Timedelta(hours=24))]
out['vaso_t0'] = out.stay_id.isin(set(ov[ov.itemid.isin(VASO)].stay_id)).astype(int)
out['inotrope_t0'] = out.stay_id.isin(set(ov[ov.itemid.isin(INO)].stay_id)).astype(int)

# renal: max(rule(cr_baseline), 3 if uo24<500)
out = out.merge(core[['stay_id','cr_baseline','uo24_ml']], on='stay_id', how='left')

out['pf_ratio'] = out.po2_min / (out.fio2_bg / 100)
def resp(pf):
    if pd.isna(pf): return np.nan
    return 0 if pf >= 400 else 1 if pf >= 300 else 2 if pf >= 200 else 3 if pf >= 100 else 4
def coag(p):
    if pd.isna(p): return np.nan
    return 0 if p >= 150 else 1 if p >= 100 else 2 if p >= 50 else 3 if p >= 20 else 4
def liver(b):
    if pd.isna(b): return np.nan
    return 0 if b < 1.2 else 1 if b < 2 else 2 if b < 6 else 3 if b < 12 else 4
def cns(g_):
    if pd.isna(g_): return np.nan
    return 0 if g_ >= 15 else 1 if g_ >= 13 else 2 if g_ >= 10 else 3 if g_ >= 6 else 4
def renal_cr(c):
    if pd.isna(c): return np.nan
    return 0 if c < 1.2 else 1 if c < 2 else 2 if c < 3.5 else 3 if c < 5 else 4
out['sofa_resp'] = out.pf_ratio.map(resp)
out['sofa_coag'] = out.plt_min.map(coag)
out['sofa_liver'] = out.bili_max.map(liver)
out['sofa_cns'] = out.gcs_min.map(cns)
out['sofa_cardio'] = np.where(out.vaso_t0==1, 3, np.where(out.inotrope_t0==1, 2, 0))
renal = np.maximum(out.cr_baseline.map(renal_cr), np.where(out.uo24_ml < 500, 3, 0))
out['sofa_renal'] = renal
comp = ['sofa_resp','sofa_coag','sofa_liver','sofa_cns','sofa_cardio','sofa_renal']
out['sofa_missing_n'] = out[comp].isna().sum(axis=1)
out['sofa_total'] = out[comp].fillna(0).sum(axis=1)

out.to_csv(LM / 'lm_sofa.csv', index=False)

# ---- validation on 692 ----
chk = out.merge(ref, on='stay_id', suffixes=('_new','_old'))
print('=== SOFA v2 validation on', len(chk), '===')
for v in ['plt_min','bili_max','po2_min','fio2_bg','gcs_min','pf_ratio']:
    a, b = chk[f'{v}_new'], chk[f'{v}_old']
    both = a.notna() & b.notna()
    print(f'{v}: both={both.sum()}, exact={(a[both]==b[both]).mean():.3f}')
for v in ['sofa_resp','sofa_coag','sofa_liver','sofa_cns','sofa_cardio','sofa_renal','sofa_total','sofa_missing_n']:
    a, b = chk[f'{v}_new'], chk[f'{v}_old']
    both = a.notna() & b.notna()
    print(f'{v}: exact={(a[both]==b[both]).mean():.3f} (n={both.sum()})')
print('vaso agree:', (chk.vaso_t0_new==chk.vaso_t0_old).mean().round(4),
      'inotrope agree:', (chk.inotrope_t0_new==chk.inotrope_t0_old).mean().round(4))
print('sofa_total corr:', np.corrcoef(chk.sofa_total_new, chk.sofa_total_old)[0,1].round(4),
      'mean abs diff:', (chk.sofa_total_new-chk.sofa_total_old).abs().mean().round(3))
