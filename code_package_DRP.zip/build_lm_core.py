# -*- coding: utf-8 -*-
"""Landmark cohort build — step A: core variables + validation vs 692 main cohort."""
import pandas as pd, numpy as np
from pathlib import Path

LM = Path(r'C:\Users\Administrator\Documents\kimi\workspace\revise_task\landmark')
EXT = Path(r'C:\Users\Administrator\Documents\kimi\workspace\DRP_weaning\extraction')
FEA = Path(r'C:\Users\Administrator\Documents\kimi\workspace\DRP_weaning\feasibility')

cand = pd.read_csv(FEA / 'candidates_t0.csv')
cand['t0'] = pd.to_datetime(cand['t0'])
cand['intime'] = pd.to_datetime(cand['intime'])
# hadm_id via icustays
icu = pd.read_csv(FEA / 'icustays.csv', usecols=['stay_id','hadm_id','outtime'])
icu['outtime'] = pd.to_datetime(icu['outtime'])
cand = cand.merge(icu, on='stay_id', how='left')
# gender + dod
pat = pd.read_csv(LM / 'lm_patients.csv', usecols=['subject_id','gender','dod'])
cand = cand.merge(pat, on='subject_id', how='left')
# deathtime (this admission)
adm = pd.read_csv(LM / 'lm_admissions.csv', usecols=['subject_id','hadm_id','deathtime'])
adm['deathtime'] = pd.to_datetime(adm['deathtime'])
cand = cand.merge(adm, on=['subject_id','hadm_id'], how='left')
cand['dod_d'] = pd.to_datetime(cand['dod'], errors='coerce') + pd.Timedelta(hours=12)
cand['death_dt'] = cand[['deathtime','dod_d']].min(axis=1)
print('candidates:', len(cand), 'with death_dt:', cand.death_dt.notna().sum())

# ---- ventilation intervals / extubation ----
pr = pd.read_csv(LM / 'lm_procedureevents.csv')
pr['starttime'] = pd.to_datetime(pr['starttime']); pr['endtime'] = pd.to_datetime(pr['endtime'])
vent = pr[pr.itemid == 225792].copy()
ext = pr[pr.itemid == 227194].copy()
unp = pr[pr.itemid.isin([225468, 225477])].copy()
trach = pr[pr.itemid.isin([225448, 226237])].copy()

# vent hours before t0 (sum of interval overlap with [intime, t0])
v = vent.merge(cand[['stay_id','t0','intime']], on='stay_id')
v['s'] = v[['starttime','intime']].max(axis=1)
v['e'] = v[['endtime','t0']].min(axis=1)
v['dur'] = (v['e'] - v['s']).dt.total_seconds() / 3600
v.loc[v['dur'] < 0, 'dur'] = 0
vb = v.groupby('stay_id')['dur'].sum().rename('vent_h_before_t0')
cand = cand.merge(vb, on='stay_id', how='left')

# first extubation after t0
e = ext.merge(cand[['stay_id','t0']], on='stay_id')
e = e[e['starttime'] > e['t0']]
fe = e.groupby('stay_id')['starttime'].min().rename('extub_time')
cand = cand.merge(fe, on='stay_id', how='left')
cand['extubated'] = cand.extub_time.notna().astype(int)

# unplanned extubation after t0
u = unp.merge(cand[['stay_id','t0']], on='stay_id')
u = u[u['starttime'] > u['t0']]
cand['unplanned_extub'] = cand.stay_id.isin(u.stay_id).astype(int)

# tracheostomy after t0
tr = trach.merge(cand[['stay_id','t0']], on='stay_id')
tr = tr[tr['starttime'] > tr['t0']]
cand['trach_after_t0'] = cand.stay_id.isin(tr.stay_id).astype(int)

# still ventilated at L = t0+30h: 225792 interval covering L
cand['L'] = cand['t0'] + pd.Timedelta(hours=30)
vv = vent.merge(cand[['stay_id','L']], on='stay_id')
onvent_L = vv[(vv.starttime <= vv.L) & (vv.endtime > vv.L)].stay_id.unique()
cand['on_vent_at_L'] = cand.stay_id.isin(onvent := set(onvent_L := onvent_L)).astype(int) if False else cand.stay_id.isin(onvent_L := onvent_L).astype(int)
cand['alive_at_L'] = ((cand.death_dt.isna()) | (cand.death_dt > cand.L)).astype(int)
cand['in_icu_at_L'] = (cand.outtime > cand.L).astype(int)

# ---- RRT exclusion (t0-24h ~ t0+30h) ----
dia = pr[pr.itemid.isin([225441, 225802, 225805])].merge(cand[['stay_id','t0']], on='stay_id')
dia = dia[(dia.starttime >= dia.t0 - pd.Timedelta(hours=24)) & (dia.starttime <= dia.t0 + pd.Timedelta(hours=30))]
cand['excl_dial'] = cand.stay_id.isin(dia.stay_id).astype(int)

# ---- diagnoses: sepsis / HF / ESRD / cirrhosis (index hadm) ----
dx = pd.read_csv(LM / 'lm_diagnoses.csv')
dx['icd_code'] = dx.icd_code.astype(str)
dxi = dx.merge(cand[['subject_id','hadm_id']], on=['subject_id','hadm_id'])
SEP = ['038','0380','0381','0382','0383','0384','0388','0389','99591','99592','78552',
 'A021','A227','A267','A327','A400','A401','A403','A408','A409','A4101','A4102','A411','A413','A414',
 'A4150','A4151','A4152','A4153','A4159','A4181','A4189','A419','B377','R6520','R6521']
HF = ['4280','4281','42820','42821','42822','42823','42830','42831','42832','42833','42840','42841','42842','42843','4289',
 'I110','I130','I132','I501','I5020','I5021','I5022','I5023','I5030','I5031','I5032','I5033','I5040','I5041','I5042','I5043',
 'I50810','I50811','I50812','I50813','I50814','I5082','I5084','I509']
ESRD = ['5856','V4511','V4512','N186','Z992']
CIRR = ['5712','5715','5716','K703','K704','K717','K721','K729','K743','K744','K745','K746','K766']
for name, codes in [('sepsis',SEP),('heart_failure',HF),('excl_esrd',ESRD),('excl_cirr',CIRR)]:
    cand[name] = cand.subject_id.isin(dxi[dxi.icd_code.isin(codes)].subject_id.unique()).astype(int)

# ---- inputevents: furo24, intake24, RBC, albumin ----
ie = pd.read_csv(LM / 'lm_inputevents.csv')
ie['starttime'] = pd.to_datetime(ie['starttime'])
ie['amount'] = pd.to_numeric(ie['amount'], errors='coerce')
m = ie.merge(cand[['stay_id','t0']], on='stay_id')
win24 = m[(m.starttime >= m.t0) & (m.starttime < m.t0 + pd.Timedelta(hours=24))]
furo = win24[win24.itemid.isin([221794, 228340])].groupby('stay_id')['amount'].sum().rename('furo24_mg')
in24 = win24.groupby('stay_id')['amount'].sum().rename('in24_ml')
cand = cand.merge(furo, on='stay_id', how='left').merge(in24, on='stay_id', how='left')
rbc = m[m.itemid == 225168]
rbc = rbc[(rbc.starttime >= rbc.t0 - pd.Timedelta(hours=12)) & (rbc.starttime <= rbc.t0 + pd.Timedelta(hours=30))]
cand['excl_rbc'] = cand.stay_id.isin(rbc.stay_id).astype(int)
alb_ids = ie[ie.itemid.isin([220862, 220863, 220864, 220865])].itemid.unique()
print('albumin itemids found:', alb_ids)
alb = m[m.itemid.isin(list(alb_ids))]
alb = alb[(alb.starttime >= alb.t0) & (alb.starttime <= alb.t0 + pd.Timedelta(hours=30))]
cand['excl_alb'] = cand.stay_id.isin(alb.stay_id).astype(int)

# ---- outputevents: urine UO24, total out24 ----
oe = pd.read_csv(LM / 'lm_outputevents.csv')
oe['charttime'] = pd.to_datetime(oe['charttime'])
oe['value'] = pd.to_numeric(oe['value'], errors='coerce')
mo = oe.merge(cand[['stay_id','t0']], on='stay_id')
win = mo[(mo.charttime >= mo.t0) & (mo.charttime < mo.t0 + pd.Timedelta(hours=24))]
urine_ids = [226559, 226560, 226566, 227489]
uo = win[win.itemid.isin(urine_ids)].groupby('stay_id')['value'].sum().rename('uo24_ml')
out24 = win.groupby('stay_id')['value'].sum().rename('out24_ml')
cand = cand.merge(uo, on='stay_id', how='left').merge(out24, on='stay_id', how='left')
cand['fb24_l'] = (cand['in24_ml'] - cand['out24_ml']) / 1000
cand['uo24_l'] = cand['uo24_ml'] / 1000

# ---- labs: hb_pre, hb_post, alb, cr_baseline ----
lab = pd.read_csv(LM / 'lm_labevents.csv')
lab['charttime'] = pd.to_datetime(lab['charttime'])
lab = lab.dropna(subset=['valuenum'])
lm_ = lab.merge(cand[['subject_id','stay_id','t0']].drop_duplicates(), on='subject_id')
def lab_last(ids, lo_h, hi_h, name):
    d = lm_[lm_.itemid.isin(ids)]
    d = d[(d.charttime >= d.t0 + pd.Timedelta(hours=lo_h)) & (d.charttime <= d.t0 + pd.Timedelta(hours=hi_h))]
    return d.sort_values('charttime').groupby('stay_id')['valuenum'].last().rename(name)
cand = cand.merge(lab_last([51222, 50811], -24, 0, 'hb_pre'), on='stay_id', how='left')
cand = cand.merge(lab_last([51222, 50811], 12, 30, 'hb_post'), on='stay_id', how='left')
cand = cand.merge(lab_last([50862], -48, 0, 'alb'), on='stay_id', how='left')
cand = cand.merge(lab_last([50912, 52546], -24*365, 0, 'cr_baseline'), on='stay_id', how='left')
cand['dhb'] = cand['hb_post'] - cand['hb_pre']
# hb_min_post for bleed rule
d = lm_[lm_.itemid.isin([51222, 50811])]
d = d[(d.charttime >= d.t0) & (d.charttime <= d.t0 + pd.Timedelta(hours=30))]
hbmin = d.groupby('stay_id')['valuenum'].min().rename('hb_min_post')
cand = cand.merge(hbmin, on='stay_id', how='left')
cand['excl_hbdrop'] = ((cand['hb_pre'] - cand['hb_min_post']) > 2).astype(int)

cand.to_csv(LM / 'lm_core.csv', index=False)
print('saved lm_core.csv', len(cand))

# ================= validation vs 692 =================
ref = pd.read_csv(EXT / 'analysis_cohort_full.csv')
for bc in ['sepsis','heart_failure','unplanned_extub','excl_rbc','excl_alb','excl_dial','excl_esrd','excl_cirr','excl_hbdrop','death28']:
    ref[bc] = ref[bc].astype(str).isin(['True','1']).astype(int)
chk = cand.merge(ref, on='stay_id', suffixes=('_new','_old'))
print('\n=== VALIDATION on', len(chk), 'stays ===')
for v, tol in [('vent_h_before_t0', 0.5), ('fb24_l', 0.05), ('uo24_ml', 5), ('furo24_mg', 1),
               ('hb_pre', 0.05), ('hb_post', 0.05), ('alb', 0.05), ('cr_baseline', 0.02)]:
    a, b = chk[f'{v}_new'], chk[f'{v}_old']
    both = a.notna() & b.notna()
    agree = ((a - b).abs() <= tol)[both].mean()
    print(f'{v}: both nonnull {both.sum()}, agree(±{tol}) {agree:.3f}, new-null {a.isna().sum()}, old-null {b.isna().sum()}')
for f in ['sepsis','heart_failure','unplanned_extub','excl_rbc','excl_alb','excl_dial','excl_esrd','excl_cirr','excl_hbdrop']:
    agree = (chk[f'{f}_new'] == chk[f'{f}_old']).mean()
    print(f'{f}: agree {agree:.4f} (new=1: {chk[f"{f}_new"].sum()}, old=1: {chk[f"{f}_old"].sum()})')
# extub_time
et = (pd.to_datetime(chk.extub_time_new) - pd.to_datetime(chk.extub_time_old)).dt.total_seconds().abs()
print('extub_time match <1min:', (et < 60).mean())
# death28
dd = chk.copy()
dd['death28_new'] = ((dd.death_dt_new.notna()) & (dd.death_dt_new <= dd.t0 + pd.Timedelta(days=28)) & (dd.death_dt_new >= dd.t0 - pd.Timedelta(days=3))).astype(int)
print('death28 agree:', (dd.death28_new == dd.death28_old).mean())
