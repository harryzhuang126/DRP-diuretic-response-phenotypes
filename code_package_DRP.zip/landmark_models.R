# Landmark analysis models: outcomes from L = t0+30h, 9 covariates
# cov: age, gender_m, vent_h_before_L(h), sofa_total, sepsis, heart_failure, furo24_mg, cr_baseline, alb
suppressMessages(library(survival))
d <- read.csv("lm_cohort.csv")
d$vent_h_before_L <- d$vent_h_before_t0 + 30
d$phenotype <- relevel(factor(d$phenotype), ref = "P1")
cov <- c("age","gender_m","vent_h_before_L","sofa_total","sepsis","heart_failure","furo24_mg","cr_baseline","alb")
dc <- d[complete.cases(d[, cov]), ]
cat("complete-case n:", nrow(dc), "of", nrow(d), "\n")
cat("missing by var:\n"); print(sapply(d[, cov], function(x) sum(is.na(x))))

fmt_or <- function(fit, term) {
  b <- coef(fit)[term]; se <- sqrt(diag(vcov(fit))[term])
  sprintf("%.3f (%.3f-%.3f), P=%.4f", exp(b), exp(b-1.96*se), exp(b+1.96*se), 2*pnorm(-abs(b/se)))
}
fmt_hr <- fmt_or

cat("\n===== A. 28-day death from L: LOGISTIC =====\n")
f <- as.formula(paste("death28_L ~ phenotype +", paste(cov, collapse = "+")))
m1 <- glm(f, dc, family = binomial)
for (t in c("phenotypeP2","phenotypeP3","phenotypeP4")) cat(t, fmt_or(m1, t), "\n")
print(table(dc$phenotype, dc$death28_L))
print(round(prop.table(table(dc$phenotype, dc$death28_L), 1)*100, 1))

cat("\n===== B. 28-day death from L: COX =====\n")
m2 <- coxph(as.formula(paste("Surv(time28, death28_L) ~ phenotype +", paste(cov, collapse = "+"))), dc)
for (t in c("phenotypeP2","phenotypeP3","phenotypeP4")) cat(t, fmt_hr(m2, t), "\n")
cat("concordance:", summary(m2)$concordance[1], "\n")
z <- cox.zph(m2)
cat("Schoenfeld global P:", z$table["GLOBAL","p"], "\n")
print(round(z$table, 4))

cat("\n===== C. AKI after L (excl AKI by L): LOGISTIC =====\n")
da <- dc[dc$aki_eligible == 1 & !is.na(dc$aki_L), ]
cat("aki analysis n:", nrow(da), "events:", sum(da$aki_L), "\n")
f3 <- as.formula(paste("aki_L ~ phenotype +", paste(cov, collapse = "+")))
m3 <- glm(f3, da, family = binomial)
for (t in c("phenotypeP2","phenotypeP3","phenotypeP4")) cat(t, fmt_or(m3, t), "\n")
print(round(prop.table(table(da$phenotype, da$aki_L), 1)*100, 1))

cat("\n===== D. phenotype distribution & disposition =====\n")
print(table(d$phenotype))
print(table(d$phenotype, d$extub_after_L))
print(table(d$phenotype, d$died_no_extub))
print(table(d$phenotype, d$trach_after_L))
cat("\nevent rates by phenotype (death28_L):\n")
print(round(tapply(d$death28_L, d$phenotype, mean)*100, 1))
cat("median time to extub after L (h) by phenotype:\n")
d$ext_lag_L <- as.numeric(as.POSIXct(d$extub_time) - as.POSIXct(d$L))/3600
print(round(tapply(d$ext_lag_L, d$phenotype, median, na.rm = TRUE), 1))
