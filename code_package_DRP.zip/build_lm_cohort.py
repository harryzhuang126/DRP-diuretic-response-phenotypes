# -*- coding: utf-8 -*-
"""Landmark analysis dataset: L = t0 + 30h.
Cohort flow: 5456 -> alive at L -> in ICU at L -> on invasive vent at L
-> lab pairing (hb_pre/hb_post/alb/uo24) -> exclusions (same rules as main) -> final.
Phenotype at t0 with main-analysis cutoffs (2.96 L / -1.0 L / +1.0 g/dL).
Outcomes from L: 28d death (L, L+28d]; AKI in [L, t0+7d] (exclude AKI already in [t0, L]).
"""
import pandas as pd, numpy as np
from pathlib import Path

LM = Path(r'C:\Users\Administrator\Documents\kimi\workspace\revise_task\landmark')
core = pd.read_csv(LM / 'lm_core.csv', parse_dates=['t0','intime','outtime','extub_time','death_dt','L'])
sofa = pd.read_csv(LM / 'lm_sofa.csv')

# updated ICD sets (reverse-engineered: must flag 0 of the 692 included patients)
dx = pd.read_csv(LM / 'lm_diagnoses.csv'); dx['icd_code'] = dx.icd_code.astype(str)
dxi = dx.merge(core[['subject_id','hadm_id']].drop_duplicates(), on=['subject_id','hadm_id'])
ESRD = ['5856','V4511','V4512']
CIRR = ['5712','5716','K703','K717','K721','K729','K743','K744','K745','K746']
core['excl_esrd'] = core.subject_id.isin(dxi[dxi.icd_code.isin(ESRD)].subject_id.unique()).astype(int)
core['excl_cirr'] = core.subject_id.isin(dxi[dxi.icd_code.isin(CIRR)].subject_id.unique()).astype(int)

ref = pd.read_csv(r'C:\Users\Administrator\Documents\kimi\workspace\DRP_weaning\extraction\analysis_cohort_full.csv')
assert core[core.stay_id.isin(ref.stay_id)].excl_esrd.sum() == 0, 'ESRD flags a 692 member!'
assert core[core.stay_id.isin(ref.stay_id)].excl_cirr.sum() == 0, 'CIRR flags a 692 member!'

# ---- creatinine for AKI windows ----
lab = pd.read_csv(LM / 'lm_labevents.csv', parse_dates=['charttime']).dropna(subset=['valuenum'])
cr = lab[lab.itemid.isin([50912, 52546])].merge(core[['subject_id','stay_id','t0','L']].drop_duplicates(), on='subject_id')
crA = cr[(cr.charttime >= cr.t0) & (cr.charttime <= cr.L)]          # [t0, L]  = t0~t0+30h
crB = cr[(cr.charttime > cr.L) & (cr.charttime <= cr.t0 + pd.Timedelta(days=7))]  # (L, t0+7d]
core = core.merge(crA.groupby('stay_id')['valuenum'].max().rename('cr_max_t0_L'), on='stay_id', how='left')
core = core.merge(crB.groupby('stay_id')['valuenum'].max().rename('cr_max_L_7d'), on='stay_id', how='left')
def aki_flag(mx, base):
    if pd.isna(mx) or pd.isna(base): return np.nan
    return int((mx >= 1.5 * base) or (mx - base >= 0.3))
core['aki_by_L'] = [aki_flag(m, b) for m, b in zip(core.cr_max_t0_L, core.cr_baseline)]
core['aki_after_L'] = [aki_flag(m, b) for m, b in zip(core.cr_max_L_7d, core.cr_baseline)]

# ---- landmark cohort flow ----
flow = {}
d = core.copy()
flow['候选（通气期间静脉呋塞米）'] = len(d)
d = d[d.alive_at_L == 1];   flow['L时点存活'] = len(d)
d = d[d.in_icu_at_L == 1];  flow['L时点仍在ICU'] = len(d)
d = d[d.on_vent_at_L == 1]; flow['L时点仍有创通气'] = len(d)
lab_ok = d[['hb_pre','hb_post','alb']].notna().all(axis=1)
d = d[lab_ok];              flow['实验室配对'] = len(d)
exc_cols = ['excl_dial','excl_esrd','excl_cirr','excl_rbc','excl_alb','excl_hbdrop']
for c in exc_cols:
    flow[f'排除:{c}'] = int(d[c].sum())
d = d[d[exc_cols].sum(axis=1) == 0]; flow['排除后'] = len(d)
d = d[d.uo24_ml.notna()];   flow['剔除尿量缺失后(最终界标队列)'] = len(d)
for k, v in flow.items(): print(f'{k}: {v}')

# ---- phenotype (main-analysis cutoffs) ----
d = d.copy()
d['high_uo'] = (d.uo24_l >= 2.96)
d['neg_fb'] = (d.fb24_l <= -1.0)
d['hemo'] = (d.dhb >= 1.0)
def pheno(r):
    if not r.high_uo: return 'P3'
    if r.neg_fb and not r.hemo: return 'P1'
    if r.hemo: return 'P2'
    return 'P4'
d['phenotype'] = d.apply(pheno, axis=1)
print(d.phenotype.value_counts())

# ---- outcomes from L ----
d['death28_L'] = ((d.death_dt.notna()) & (d.death_dt > d.L) & (d.death_dt <= d.L + pd.Timedelta(days=28))).astype(int)
d['ttd_d'] = np.where(d.death_dt.notna(), (d.death_dt - d.L).dt.total_seconds() / 86400, np.nan)
d['time28'] = np.where(d.death28_L == 1, d.ttd_d, 28.0)
d['time28'] = d['time28'].clip(lower=0.05)  # avoid 0
# AKI after L, excluding those already AKI by L
d['aki_eligible'] = (d.aki_by_L == 0) & d.aki_after_L.notna()
d['aki_L'] = np.where(d.aki_eligible, d.aki_after_L, np.nan)

# ---- disposition after L (for reporting) ----
d['extub_after_L'] = ((d.extub_time.notna()) & (d.extub_time > d.L)).astype(int)
d['died_no_extub'] = ((d.extub_after_L == 0) & (d.death_dt.notna()) & (d.death_dt <= d.outtime)).astype(int)
d['trach_after_L'] = d.trach_after_t0  # trach after t0 (all after L in this subset since on vent at L)

# ---- covariates ----
d = d.merge(sofa[['stay_id','sofa_total','sofa_missing_n','gcs_min','vaso_t0','inotrope_t0']], on='stay_id', how='left')
d['gender_m'] = (d.gender == 'M').astype(int)
print('\ncohort n:', len(d))
print('death28_L:', d.death28_L.sum(), f"({d.death28_L.mean()*100:.1f}%)")
print('aki eligible:', int(d.aki_eligible.sum()), 'aki_L:', int(np.nansum(d.aki_L)),
      f"({np.nanmean(d.aki_L)*100:.1f}%)")
print('aki_by_L (excluded from AKI analysis):', int((d.aki_by_L == 1).sum()))
print('\ndisposition: extub after L:', d.extub_after_L.sum(), '| died w/o extub:', d.died_no_extub.sum(),
      '| trach:', d.trach_after_L.sum())
d.to_csv(LM / 'lm_cohort.csv', index=False)
print('saved lm_cohort.csv')
