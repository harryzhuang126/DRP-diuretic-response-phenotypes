## ====================================================================
## DRP revision round 2 — SOFA rebuilt with PRE-t0 data only (sofa_total_pre)
## cov9 = age, male, vent_h_before_t0, sofa_total_pre, sepsis, heart_failure,
##        furo24_mg, cr_baseline, alb
## Mirrors R4_cov9_locked.R + adds:
##   [8b] wide-window v3 with FULL cov9 (sofa_total_pre merged)
##   [9b] phenotype multinomial-GPS IPW (replaces/extends dose-based IPW)
##   [11] continuous UO24 + FB24 + phenotype joint model (cov9)
## ====================================================================
OUT <- "C:/Users/Administrator/Documents/kimi/workspace/revise_task/analysis"
df <- read.csv(file.path(OUT, "cohort692_enhanced_v2.csv"), stringsAsFactors = FALSE)
df$phenotype <- factor(df$phenotype, levels = c("P1_effective_mobilization",
  "P2_intravascular_depletion","P3_diuretic_resistance","P4_mixed"))
df$male <- as.integer(df$gender == "M")
cov9 <- c("age","male","vent_h_before_t0","sofa_total_pre","sepsis","heart_failure",
          "furo24_mg","cr_baseline","alb")

auc_fun <- function(y, p) {
  r <- rank(p, ties.method = "average"); n1 <- sum(y == 1); n0 <- sum(y == 0)
  (sum(r[y == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}
boot_auc_ci <- function(y, p, B = 2000, seed = 42) {
  set.seed(seed); n <- length(y); v <- numeric(B)
  for (b in seq_len(B)) {
    idx <- sample.int(n, n, replace = TRUE)
    if (length(unique(y[idx])) < 2) { v[b] <- NA; next }
    v[b] <- auc_fun(y[idx], p[idx])
  }
  quantile(v, c(.025, .975), na.rm = TRUE)
}
vif_fun <- function(X) {
  out <- numeric(ncol(X))
  for (j in seq_len(ncol(X))) {
    r2 <- summary(lm(X[, j] ~ X[, -j]))$r.squared
    out[j] <- 1 / (1 - r2)
  }
  setNames(out, colnames(X))
}
smd <- function(x, g, w = NULL) {
  if (is.null(w)) w <- rep(1, length(x))
  m1 <- weighted.mean(x[g == 1], w[g == 1]); m0 <- weighted.mean(x[g == 0], w[g == 0])
  v1 <- weighted.mean((x[g == 1] - m1)^2, w[g == 1]); v0 <- weighted.mean((x[g == 0] - m0)^2, w[g == 0])
  (m1 - m0) / sqrt((v1 + v0) / 2)
}
print_or <- function(fit, pre = "") {
  s <- summary(fit)$coefficients
  for (i in grep("pheno", rownames(s)))
    cat(sprintf("%s%-38s OR=%.3f [%.3f-%.3f] p=%.4g\n", pre, rownames(s)[i],
                exp(s[i,1]), exp(s[i,1]-1.96*s[i,2]), exp(s[i,1]+1.96*s[i,2]), s[i,4]))
}

sink(file.path(OUT, "R6_sofapre_rerun.txt"))
cat("=== DRP revision R2 — sofa_total_pre (pre-t0 data only) locked results ===\n")
cat("Date:", as.character(Sys.Date()), " R:", R.version.string, "\n")
cat("covariates:", paste(cov9, collapse = ", "), "\n")

dcc <- df[complete.cases(df[, c(cov9)]), ]
cat("complete-case n =", nrow(dcc), "of", nrow(df), "\n")
cat("EPV check: death28 events =", sum(dcc$death28), "; params = 12 ->",
    round(sum(dcc$death28)/12, 1), "\n")
cat("sofa_total vs sofa_total_pre: mean", round(mean(dcc$sofa_total),2), "->",
    round(mean(dcc$sofa_total_pre),2), "; changed n =", sum(dcc$sofa_total != dcc$sofa_total_pre), "\n")

## ============ 1. nested models fail48 ============
cat("\n--- [1] Nested models (fail48): M1=cov9+FB24, M2=M1+UO24, M3=M2+DRP ---\n")
y <- dcc$fail48
f1 <- as.formula(paste("fail48 ~", paste(c(cov9, "fb24_l"), collapse = " + ")))
f2 <- as.formula(paste("fail48 ~", paste(c(cov9, "fb24_l", "uo24_l"), collapse = " + ")))
f3 <- as.formula(paste("fail48 ~", paste(c(cov9, "fb24_l", "uo24_l", "phenotype"), collapse = " + ")))
m1 <- glm(f1, dcc, family = binomial); m2 <- glm(f2, dcc, family = binomial); m3 <- glm(f3, dcc, family = binomial)
p1 <- predict(m1, type = "response"); p2 <- predict(m2, type = "response"); p3 <- predict(m3, type = "response")
a1 <- auc_fun(y, p1); a2 <- auc_fun(y, p2); a3 <- auc_fun(y, p3)
ci1 <- boot_auc_ci(y, p1); ci2 <- boot_auc_ci(y, p2); ci3 <- boot_auc_ci(y, p3)
cat(sprintf("AUC M1 = %.3f [%.3f-%.3f]\n", a1, ci1[1], ci1[2]))
cat(sprintf("AUC M2 = %.3f [%.3f-%.3f]\n", a2, ci2[1], ci2[2]))
cat(sprintf("AUC M3 = %.3f [%.3f-%.3f]\n", a3, ci3[1], ci3[2]))
idi_f <- function(y, po, pn) (mean(pn[y==1]) - mean(po[y==1])) - (mean(pn[y==0]) - mean(po[y==0]))
nri_f <- function(y, po, pn) { up <- pn > po
  (mean(up[y==1]) - mean(!up[y==1])) + (mean(!up[y==0]) - mean(up[y==0])) }
B <- 2000; set.seed(1); n <- length(y)
d21 <- d32 <- idi32 <- nri32 <- numeric(B)
for (b in seq_len(B)) {
  idx <- sample.int(n, n, TRUE)
  if (length(unique(y[idx])) < 2) next
  d21[b] <- auc_fun(y[idx], p2[idx]) - auc_fun(y[idx], p1[idx])
  d32[b] <- auc_fun(y[idx], p3[idx]) - auc_fun(y[idx], p2[idx])
  idi32[b] <- idi_f(y[idx], p2[idx], p3[idx]); nri32[b] <- nri_f(y[idx], p2[idx], p3[idx])
}
qq <- function(v) quantile(v, c(.025, .975), na.rm = TRUE)
cat(sprintf("dAUC M2-M1 = %.4f [%.4f-%.4f]\n", a2 - a1, qq(d21)[1], qq(d21)[2]))
cat(sprintf("dAUC M3-M2 = %.4f [%.4f-%.4f]\n", a3 - a2, qq(d32)[1], qq(d32)[2]))
cat(sprintf("IDI  M3 vs M2 = %.4f [%.4f-%.4f]\n", idi_f(y,p2,p3), qq(idi32)[1], qq(idi32)[2]))
cat(sprintf("cNRI M3 vs M2 = %.4f [%.4f-%.4f]\n", nri_f(y,p2,p3), qq(nri32)[1], qq(nri32)[2]))

## ============ 2. M3 calibration ============
cat("\n--- [2] M3 calibration ---\n")
lp3 <- predict(m3)
cat(sprintf("apparent intercept = %.4f, slope = %.4f\n",
            glm(y ~ offset(lp3), family = binomial)$coef[1],
            glm(y ~ lp3, family = binomial)$coef[2]))
grp <- cut(p3, breaks = unique(quantile(p3, probs = seq(0, 1, length.out = 11))), include.lowest = TRUE)
obs <- tapply(y, grp, sum); exp_ <- tapply(p3, grp, sum); nn <- tapply(y, grp, length)
hl <- sum((obs - exp_)^2 / (exp_ * (1 - exp_ / nn)))
cat(sprintf("Hosmer-Lemeshow chi2 = %.3f (df=%d), P = %.4f\n", hl, length(nn) - 2,
            pchisq(hl, length(nn) - 2, lower.tail = FALSE)))
calib_tbl <- data.frame(decile = seq_along(nn), n = as.integer(nn), obs = as.integer(obs),
                        exp = round(as.numeric(exp_), 1), obs_rate = round(as.numeric(obs/nn), 4),
                        pred_mean = round(as.numeric(tapply(p3, grp, mean)), 4))
print(calib_tbl)
write.csv(calib_tbl, file.path(OUT, "calibration_deciles_M3_sofapre.csv"), row.names = FALSE)
set.seed(11); B2 <- 1000; slopes <- numeric(B2)
for (b in seq_len(B2)) {
  idx <- sample.int(n, n, TRUE)
  mb <- tryCatch(glm(f3, dcc[idx, ], family = binomial), error = function(e) NULL)
  if (is.null(mb)) next
  lp_orig <- predict(mb, newdata = dcc)
  slopes[b] <- coef(glm(y ~ lp_orig, family = binomial))[2]
}
cat(sprintf("bootstrap-corrected calibration slope = %.3f [%.3f-%.3f] (B=1000)\n",
            mean(slopes), quantile(slopes, .025, na.rm=TRUE), quantile(slopes, .975, na.rm=TRUE)))

## ============ 3. fail48 phenotype model ============
cat("\n--- [3] fail48 ~ cov9 + phenotype (NO FB24/UO24) ---\n")
mf <- glm(as.formula(paste("fail48 ~", paste(c(cov9, "phenotype"), collapse = " + "))), dcc, family = binomial)
print_or(mf)

## ============ 4. 28d death ============
cat("\n--- [4a] death28 logistic ---\n")
md <- glm(as.formula(paste("death28 ~", paste(c(cov9, "phenotype"), collapse = " + "))), dcc, family = binomial)
print_or(md)
cat("\n--- [4b] corrected Cox (origin t0) ---\n")
library(survival)
cx <- coxph(as.formula(paste("Surv(death28_time_d, death28) ~", paste(c(cov9, "phenotype"), collapse = " + "))), dcc)
scx <- summary(cx)
for (i in grep("phenotype", rownames(scx$coefficients)))
  cat(sprintf("%-38s HR=%.3f [%.3f-%.3f] p=%.4g\n", rownames(scx$coefficients)[i],
              scx$coefficients[i,"exp(coef)"], scx$conf.int[i,"lower .95"],
              scx$conf.int[i,"upper .95"], scx$coefficients[i,"Pr(>|z|)"]))
zp <- cox.zph(cx)
cat("Schoenfeld:\n"); print(round(zp$table, 4))

## ============ 5. AKI logistic ============
cat("\n--- [5] aki_kdigo logistic ---\n")
ma <- glm(as.formula(paste("aki_kdigo ~", paste(c(cov9, "phenotype"), collapse = " + "))), dcc, family = binomial)
print_or(ma)

## ============ 6. VIF ============
cat("\n--- [6] VIF ---\n")
mm_sec <- model.matrix(as.formula(paste(" ~", paste(c(cov9, "phenotype"), collapse = " + "))), dcc)[, -1]
v_sec <- vif_fun(mm_sec); print(round(v_sec, 2)); cat(sprintf("range %.2f-%.2f\n", min(v_sec), max(v_sec)))

## ============ 7. sensitivities ============
cat("\n--- [7] sensitivities ---\n")
for (s in c("S1_dhb0.5","S2_dhb1.5")) {
  thr <- ifelse(s == "S1_dhb0.5", 0.5, 1.5)
  dd <- dcc
  dd$hemo_s <- as.integer(dd$dhb >= thr)
  dd$pheno_s <- factor(ifelse(!dd$high_uo, "P3",
                       ifelse(dd$neg_fb & dd$hemo_s == 1, "P2",
                       ifelse(dd$neg_fb, "P1", "P4"))), levels = c("P1","P2","P3","P4"))
  mdead <- glm(as.formula(paste("death28 ~", paste(c(cov9, "pheno_s"), collapse = " + "))), dd, family = binomial)
  maki  <- glm(as.formula(paste("aki_kdigo ~", paste(c(cov9, "pheno_s"), collapse = " + "))), dd, family = binomial)
  cat(sprintf("[%s] n=%d, P3 count=%d\n", s, nrow(dd), sum(dd$pheno_s == "P3")))
  print_or(mdead, "  death ")
  print_or(maki,  "  AKI   ")
}
dd <- dcc[dcc$unplanned_extub == 0, ]
cat(sprintf("[S3 excl unplanned] n=%d (excluded %d)\n", nrow(dd), nrow(dcc) - nrow(dd)))
print_or(glm(as.formula(paste("death28 ~", paste(c(cov9, "phenotype"), collapse = " + "))), dd, family = binomial), "  death ")
print_or(glm(as.formula(paste("aki_kdigo ~", paste(c(cov9, "phenotype"), collapse = " + "))), dd, family = binomial), "  AKI   ")
dd <- dcc[dcc$pre_AKI_at_t0 == 0, ]
cat(sprintf("[S5 excl pre-existing AKI at t0] n=%d (excluded %d)\n", nrow(dd), nrow(dcc) - nrow(dd)))
print_or(glm(as.formula(paste("death28 ~", paste(c(cov9, "phenotype"), collapse = " + "))), dd, family = binomial), "  death ")
print_or(glm(as.formula(paste("aki_kdigo ~", paste(c(cov9, "phenotype"), collapse = " + "))), dd, family = binomial), "  AKI   ")
cx5 <- coxph(as.formula(paste("Surv(death28_time_d, death28) ~", paste(c(cov9, "phenotype"), collapse = " + "))), dd)
s5 <- summary(cx5)
for (i in grep("phenotype", rownames(s5$coefficients)))
  cat(sprintf("  Cox  %-33s HR=%.3f [%.3f-%.3f] p=%.4g\n", rownames(s5$coefficients)[i],
              s5$coefficients[i,"exp(coef)"], s5$conf.int[i,"lower .95"], s5$conf.int[i,"upper .95"], s5$coefficients[i,"Pr(>|z|)"]))

## ============ 8b. wide-window v3 with FULL cov9 ============
cat("\n--- [8b] wide-window v3 cohort, FULL cov9 (sofa_total_pre merged) ---\n")
v3 <- read.csv(file.path(OUT, "cohort_v3_cov9.csv"), stringsAsFactors = FALSE)
for (bc in c("death28","aki_kdigo","sepsis","heart_failure")) v3[[bc]] <- as.integer(v3[[bc]] %in% c("True", TRUE, "1", 1))
v3$male <- as.integer(v3$gender == "M")
v3$cr_baseline <- v3$cr_baseline_v3
v3$phenotype <- factor(v3$phenotype, levels = levels(dcc$phenotype))
cov9v <- c("age","male","vent_h_before_t0","sofa_total_pre","sepsis","heart_failure",
           "furo24_mg","cr_baseline","alb")
v3c <- v3[complete.cases(v3[, cov9v]), ]
cat("v3 complete-case n =", nrow(v3c), "of", nrow(v3),
    " death28 =", sum(v3c$death28), " AKI =", sum(v3c$aki_kdigo), "\n")
print_or(glm(as.formula(paste("death28 ~", paste(c(cov9v, "phenotype"), collapse = " + "))), v3c, family = binomial), "  death ")
print_or(glm(as.formula(paste("aki_kdigo ~", paste(c(cov9v, "phenotype"), collapse = " + "))), v3c, family = binomial), "  AKI   ")

## ============ 9a. IPW dose-based (re-run with sofa_pre) ============
cat("\n--- [9a] IPW dose-based (PS ~ 8 baseline cov excl furo24) ---\n")
dcc$highdose <- as.integer(dcc$furo24_mg >= 60)
cat("high-dose n =", sum(dcc$highdose), "of", nrow(dcc), "\n")
ps_cov <- c("age","male","vent_h_before_t0","sofa_total_pre","sepsis","heart_failure","cr_baseline","alb")
psm <- glm(as.formula(paste("highdose ~", paste(ps_cov, collapse = " + "))), dcc, family = binomial)
ps <- predict(psm, type = "response")
dcc$sw <- ifelse(dcc$highdose == 1, mean(dcc$highdose) / ps, (1 - mean(dcc$highdose)) / (1 - ps))
qt <- quantile(dcc$sw, c(0.01, 0.99))
dcc$sw_t <- pmin(pmax(dcc$sw, qt[1]), qt[2])
cat(sprintf("stabilized weights min=%.3f max=%.3f mean=%.3f sd=%.3f; trunc (%.3f,%.3f)\n",
            min(dcc$sw), max(dcc$sw), mean(dcc$sw), sd(dcc$sw), qt[1], qt[2]))
smd_tbl <- data.frame(var = ps_cov,
  smd_before = round(sapply(ps_cov, function(v) smd(dcc[[v]], dcc$highdose)), 3),
  smd_after  = round(sapply(ps_cov, function(v) smd(dcc[[v]], dcc$highdose, dcc$sw_t)), 3))
print(smd_tbl)
write.csv(smd_tbl, file.path(OUT, "ipw_smd_table_sofapre.csv"), row.names = FALSE)
mw <- glm(f3, dcc, family = binomial, weights = sw_t)
print_or(mw, "  IPW fail48(M3) ")
set.seed(7); boot_or <- matrix(NA, 1000, 3)
for (b in 1:1000) {
  idx <- sample.int(nrow(dcc), nrow(dcc), TRUE); db <- dcc[idx, ]
  psm_b <- tryCatch(glm(as.formula(paste("highdose ~", paste(ps_cov, collapse = " + "))), db, family = binomial), error = function(e) NULL)
  if (is.null(psm_b)) next
  ps_b <- predict(psm_b, type = "response")
  w_b <- ifelse(db$highdose == 1, mean(db$highdose) / ps_b, (1 - mean(db$highdose)) / (1 - ps_b))
  qtb <- quantile(w_b, c(0.01, 0.99)); w_b <- pmin(pmax(w_b, qtb[1]), qtb[2])
  mb <- tryCatch(glm(f3, db, family = binomial, weights = w_b), error = function(e) NULL)
  if (is.null(mb)) next
  boot_or[b, ] <- coef(mb)[grep("phenotype", names(coef(mb)))]
}
ci_or <- apply(boot_or, 2, quantile, c(.025, .975), na.rm = TRUE)
for (j in 1:3) cat(sprintf("  IPW boot CI %s: OR=%.3f [%.3f-%.3f]\n", c("P2","P3","P4")[j],
  exp(coef(mw)[grep("phenotype", names(coef(mw)))][j]), exp(ci_or[1,j]), exp(ci_or[2,j])))

## ============ 9b. phenotype multinomial-GPS IPW ============
cat("\n--- [9b] GPS-IPW: multinomial PS for phenotype (8 baseline cov excl furo24) ---\n")
suppressMessages(library(nnet))
gps_cov <- ps_cov
fgps <- as.formula(paste("phenotype ~", paste(gps_cov, collapse = " + ")))
gps <- multinom(fgps, dcc, trace = FALSE)
phat <- predict(gps, type = "probs")
pmarg <- prop.table(table(dcc$phenotype))
w <- numeric(nrow(dcc))
for (k in levels(dcc$phenotype))
  w[dcc$phenotype == k] <- pmarg[k] / phat[dcc$phenotype == k, k]
dcc$gw <- w
qtg <- quantile(dcc$gw, c(0.01, 0.99))
dcc$gw_t <- pmin(pmax(dcc$gw, qtg[1]), qtg[2])
cat(sprintf("GPS stabilized weights min=%.3f max=%.3f mean=%.3f sd=%.3f; trunc (%.3f,%.3f)\n",
            min(dcc$gw), max(dcc$gw), mean(dcc$gw), sd(dcc$gw), qtg[1], qtg[2]))
ess <- tapply(dcc$gw_t, dcc$phenotype, function(x) sum(x)^2 / sum(x^2))
cat("ESS by phenotype:", paste(round(ess, 1), collapse = " / "), "\n")
## pairwise max SMD before/after
pairs <- combn(levels(dcc$phenotype), 2, simplify = FALSE)
smd_row <- function(v) {
  x <- dcc[[v]]
  b <- max(sapply(pairs, function(pr) {
    idx <- dcc$phenotype %in% pr
    abs(smd(as.numeric(x[idx]), as.integer(dcc$phenotype[idx] == pr[2])))
  }))
  a <- max(sapply(pairs, function(pr) {
    idx <- dcc$phenotype %in% pr
    abs(smd(as.numeric(x[idx]), as.integer(dcc$phenotype[idx] == pr[2]), dcc$gw_t[idx]))
  }))
  c(b, a)
}
smd_gps <- t(sapply(gps_cov, smd_row))
smd_gps <- data.frame(var = gps_cov, maxpair_smd_before = round(smd_gps[,1], 3),
                      maxpair_smd_after = round(smd_gps[,2], 3))
print(smd_gps)
write.csv(smd_gps, file.path(OUT, "gps_smd_table_sofapre.csv"), row.names = FALSE)

gps_outcome <- function(yn, label) {
  f <- as.formula(paste(yn, "~", paste(c(cov9, "phenotype"), collapse = " + ")))
  mw2 <- glm(f, dcc, family = binomial, weights = gw_t)
  print_or(mw2, paste0("  GPS-IPW ", label, " "))
  set.seed(7); bo <- matrix(NA, 1000, 3)
  for (b in 1:1000) {
    idx <- sample.int(nrow(dcc), nrow(dcc), TRUE); db <- dcc[idx, ]
    g_b <- tryCatch(multinom(fgps, db, trace = FALSE), error = function(e) NULL)
    if (is.null(g_b)) next
    ph <- predict(g_b, type = "probs")
    pm <- prop.table(table(db$phenotype))
    wb <- numeric(nrow(db))
    for (k in levels(db$phenotype))
      wb[db$phenotype == k] <- pm[k] / ph[db$phenotype == k, k]
    qtb <- quantile(wb, c(0.01, 0.99)); wb <- pmin(pmax(wb, qtb[1]), qtb[2])
    mb <- tryCatch(glm(f, db, family = binomial, weights = wb), error = function(e) NULL)
    if (is.null(mb)) next
    bo[b, ] <- coef(mb)[grep("phenotype", names(coef(mb)))]
  }
  ci <- apply(bo, 2, quantile, c(.025, .975), na.rm = TRUE)
  est <- coef(mw2)[grep("phenotype", names(coef(mw2)))]
  for (j in 1:3) cat(sprintf("  GPS-IPW %s boot CI %s: OR=%.3f [%.3f-%.3f]\n", label, c("P2","P3","P4")[j],
    exp(est[j]), exp(ci[1,j]), exp(ci[2,j])))
}
gps_outcome("fail48", "fail48")
gps_outcome("death28", "death28")
gps_outcome("aki_kdigo", "AKI")

## ============ 10. AKI addendum ============
cat("\n--- [10] AKI addendum: (t0+24h, t0+7d], exclude aki_pre24 ---\n")
dsub <- dcc[dcc$aki_pre24 == 0, ]
dsub$aki_new <- as.integer(!is.na(dsub$aki_24h_7d) & dsub$aki_24h_7d == 1)
cat("n =", nrow(dsub), " new AKI =", sum(dsub$aki_new), "\n")
print(table(dsub$phenotype, dsub$aki_new))
print_or(glm(as.formula(paste("aki_new ~", paste(c(cov9, "phenotype"), collapse = " + "))), dsub, family = binomial))

## ============ 11. continuous UO24 + FB24 + phenotype (cov9) ============
cat("\n--- [11] continuous UO24 + FB24 + phenotype joint model ---\n")
for (yn in c("death28", "aki_kdigo")) {
  f <- as.formula(paste(yn, "~", paste(c(cov9, "uo24_l", "fb24_l", "phenotype"), collapse = " + ")))
  mcont <- glm(f, dcc, family = binomial)
  cat(sprintf("[%s] n=%d\n", yn, nrow(dcc)))
  print_or(mcont, "  pheno ")
  s <- summary(mcont)$coefficients
  for (v in c("uo24_l", "fb24_l"))
    cat(sprintf("  %-36s OR=%.3f [%.3f-%.3f] p=%.4g\n", v,
                exp(s[v,1]), exp(s[v,1]-1.96*s[v,2]), exp(s[v,1]+1.96*s[v,2]), s[v,4]))
}

sink()
cat("DONE\n")
