# 数据字典（analysis_cohort_full.csv / analysis_cohort_v3.csv）

每行＝一次 ICU 入住（stay_id 唯一）。时间均为数据库移位后时间。

## 标识与时间
| 列 | 含义 |
|---|---|
| stay_id / subject_id / hadm_id | ICU 入住 / 患者 / 住院标识 |
| t0 | 暴露起点（呋塞米给药后定义的利尿观察起点） |
| extub_time | 拔管时间 |
| intime / outtime | ICU 入/出室时间 |
| dod | 死亡日期（部分仅精确到天；空＝无死亡记录） |
| in_v2 / in_v3 | 是否满足 wide_v2 / wide_v3 实验室配对窗口 |

## 排除标记（True＝触发该排除；excluded＝任一触发）
| 列 | 含义 |
|---|---|
| excl_esrd | 终末期肾病（ICD） |
| excl_cirr | 肝硬化（ICD） |
| excl_bleed | 活动性出血诊断 |
| excl_rbc / excl_rbc_v2 | 观察窗内红细胞输注（v2 窗口口径） |
| excl_alb / excl_alb_v2 | 观察窗内白蛋白输注（v2 窗口口径） |
| excl_dial | 观察窗内透析 |
| excl_hbdrop | Hb 骤降（提示失血，hb_min_post 判定） |

## 暴露与表型
| 列 | 含义 |
|---|---|
| uo24_ml / uo24_l | t0 至 t0+24h 尿量（mL / L） |
| in24_ml / out24_ml | 同期入量 / 出量（mL） |
| fb24_l | 24h 液体平衡（入−出，L；负值＝负平衡） |
| furo24_mg | 24h 呋塞米等效剂量（mg） |
| hb_pre / hb_post | 基线 Hb（t0 前 24h 最近一次）/ 利尿后 Hb（t0+12~30h 最近一次），g/dL |
| dhb | hb_post − hb_pre（g/dL） |
| alb | 基线白蛋白（t0 前 48h 最近一次），g/dL |
| high_uo | uo24_l ≥ 队列中位数（2.96 L） |
| neg_fb | fb24_l ≤ −1.0 L |
| hemo | dhb ≥ +1.0 g/dL |
| phenotype | 四象限表型：P1 有效动员＝high_uo&neg_fb&!hemo；P2 血管内耗竭＝high_uo&neg_fb&hemo；P3 利尿剂抵抗＝!high_uo；P4 混合＝high_uo&!neg_fb |
| uo_alb | 尿量/白蛋白比值 |
| vent_h_before_t0 | t0 前已通气小时数 |
| unplanned_extub | 非计划拔管 |

## 协变量
| 列 | 含义 |
|---|---|
| age / gender | 年龄（岁）/ 性别（M/F） |
| sepsis / heart_failure | 脓毒症 / 心力衰竭（ICD） |
| sofa_total | 自建 SOFA 总分（六器官分项：sofa_resp/coag/liver/cns/cardio/renal；P/F 缺失记 0，缺失项数 sofa_missing_n） |
| plt_min, bili_max, cr_sofa, gcs_min | SOFA 分项原始值：血小板、胆红素、肌酐（评分用）、GCS |
| po2_min, fio2_bg, fio2_frac, pf_ratio | 氧合相关：最低 PaO2、FiO2、P/F（仅 ~40% 可得） |
| map_min, vaso_t0, inotrope_t0 | 循环：最低 MAP（未用）、t0 时血管活性药/正性肌力药 |
| cr_baseline, bun_baseline | 基线肌酐 / 尿素氮 |
| bun_cr | BUN/Cr 比值 |

## 结局
| 列 | 含义 |
|---|---|
| fail48 | 主要结局：48h 脱机失败（死亡 death48 或再插管 re48） |
| re48 / death48 | 48h 内再插管 / 死亡 |
| aki_kdigo | 拔管后 48h 内 KDIGO 肌酐标准 AKI（cr_post48_max vs cr_baseline） |
| cr_post48_max | 拔管后 48h 内最高肌酐 |
| death28 | 28 天死亡 |
| vfd28 / ventdays28 | 28 天无通气天数 / 通气天数 |
| icu_los_d | ICU 住院时长（天） |
| vaso_post48 | 拔管后 48h 新发/升级血管活性药 |

## 关键 itemid 映射（MIMIC-IV v3.1，已与 d_items/d_labitems 逐一核对）
| 数据 | 表 | itemid（标签） |
|---|---|---|
| 有创通气 | procedureevents | 225792（Invasive Ventilation） |
| 拔管 | procedureevents | 227194（Extubation）；非计划拔管 225468/225477 |
| 呋塞米 | inputevents | 221794、228340（等效剂量累加） |
| 尿量 | outputevents | 226559（Foley）、226560（Void）、226566、227489（GU Irrigant/Urine Volume Out）；排除 226627/226631（OR/PACU） |
| 血红蛋白 | labevents | 51222（Hemoglobin，主用）；50811（血气，补充） |
| 白蛋白 | labevents | 50862 / 52022 / 53085 合并取最近（SAP v1.1 冻结） |
| 肌酐 | labevents | 50912（主用）、52546 |
| 尿素氮 | labevents | 51006（主用）、52647 |
| 血小板 | labevents | 51265（Platelet Count） |
| 总胆红素 | labevents | 50885（Bilirubin, Total） |
| pO2 | labevents（血气） | 50821（pO2）；50816（Oxygen，血气） |
| 乳酸 | labevents | 53154（Lactate，随 SOFA 提取集一并提取，未用于本分析） |
| FiO2 | chartevents | 226754（FiO2ApacheIIValue）；227010（FiO2_ApacheIV，备选） |
| GCS | chartevents | 220739（Eye Opening）+ 223900（Verbal Response）+ 223901（Motor Response），三项合成；valuenum 取值（value 列为文本描述） |
| PEEP | chartevents | 220339（PEEP set）、224700（Total PEEP Level） |
| 呼吸力学 | chartevents | 224685（Tidal Volume observed）、224686（spontaneous）、224689（RR spontaneous）、224690（RR Total） |
| 心率/体温/体重 | chartevents | 220045（HR）、223762（Temperature C）、224639（Daily Weight）、226512（Admission Weight） |
