# -*- coding: utf-8 -*-
"""
Rebuild SOFA using ONLY pre-t0 data (expert critique #1):
- sofa_cardio_pre: vaso/inotrope infusions overlapping [t0-24h, t0] (was t0±24h)
- sofa_renal_pre : max(rule(cr_baseline), 3 if UO[t0-24h,t0)<500mL) (was UO[t0,t0+24h))
- resp/coag/liver/cns unchanged (already [t0-24h, t0])
Outputs:
  analysis/cohort692_enhanced_v2.csv   (adds *_pre columns)
  landmark/lm_sofa_pre.csv             (stay_id + *_pre columns, all 5456 stays)
Also validates the urine itemid set by reproducing uo24_ml in [t0, t0+24h).
"""
import pandas as pd, numpy as np
from pathlib import Path

ROOT = Path(r'C:\Users\Administrator\Documents\kimi\workspace')
REV = ROOT / 'revise_task'
EXT = ROOT / 'DRP_weaning' / 'extraction'
LM = REV / 'landmark'

UO_ITEMS = [226559, 226560, 226566, 227489]          # urine output (excl 226627/226631)
VASO = [221906, 221289, 222315, 221749, 221662, 229617, 229709, 229764]
INO = [221653, 221986]

def renal_cr(c):
    if pd.isna(c): return np.nan
    return 0 if c < 1.2 else 1 if c < 2 else 2 if c < 3.5 else 3 if c < 5 else 4

def compute_pre(t0map, out_csv, in_csv):
    """t0map: DataFrame stay_id,t0. Returns DataFrame stay_id, uo_pre24_ml, uo24_check_ml, vaso_pre, inotrope_pre."""
    oe = pd.read_csv(out_csv, parse_dates=['charttime'])
    oe = oe[oe.itemid.isin(UO_ITEMS)]
    m = oe.merge(t0map, on='stay_id')
    pre = m[(m.charttime >= m.t0 - pd.Timedelta(hours=24)) & (m.charttime < m.t0)]
    uo_pre = pre.groupby('stay_id')['value'].sum().rename('uo_pre24_ml')
    post = m[(m.charttime >= m.t0) & (m.charttime < m.t0 + pd.Timedelta(hours=24))]
    uo_post = post.groupby('stay_id')['value'].sum().rename('uo24_check_ml')
    res = t0map[['stay_id']].copy().merge(uo_pre, on='stay_id', how='left').merge(uo_post, on='stay_id', how='left')

    ie = pd.read_csv(in_csv, parse_dates=['starttime', 'endtime'])
    vv = ie[ie.itemid.isin(VASO + INO)].merge(t0map, on='stay_id')
    ov = vv[(vv.endtime >= vv.t0 - pd.Timedelta(hours=24)) & (vv.starttime <= vv.t0)]
    res['vaso_pre'] = res.stay_id.isin(set(ov[ov.itemid.isin(VASO)].stay_id)).astype(int)
    res['inotrope_pre'] = res.stay_id.isin(set(ov[ov.itemid.isin(INO)].stay_id)).astype(int)
    return res

# ============ main 692 ============
df = pd.read_csv(REV / 'analysis' / 'cohort692_enhanced.csv', parse_dates=['t0'])
pre = compute_pre(df[['stay_id', 't0']], EXT / 'cohort_outputevents.csv', EXT / 'cohort_inputevents.csv')
d = df.merge(pre, on='stay_id', how='left')

# validate urine itemid set against stored uo24_ml
chk = d[['uo24_ml', 'uo24_check_ml']].dropna()
exact = (np.abs(chk.uo24_ml - chk.uo24_check_ml) < 1).mean()
print(f'UO24 replication vs stored uo24_ml: n={len(chk)}, exact={exact:.4f}, '
      f'corr={np.corrcoef(chk.uo24_ml, chk.uo24_check_ml)[0,1]:.4f}, '
      f'median abs diff={np.median(np.abs(chk.uo24_ml - chk.uo24_check_ml)):.1f} mL')

d['sofa_cardio_pre'] = np.where(d.vaso_pre == 1, 3, np.where(d.inotrope_pre == 1, 2, 0))
renal_cr_score = d.cr_baseline.map(renal_cr)
d['sofa_renal_pre'] = np.maximum(renal_cr_score, np.where(d.uo_pre24_ml < 500, 3, 0))
# if no urine rows at all in pre window -> NaN guard: uo_pre24_ml NaN means no records; treat <500 check as False->0 like post-hoc original (missing uo24_ml => original got NaN? check)
print('uo_pre24_ml NaN count (no pre-window urine rows):', d.uo_pre24_ml.isna().sum())
print('uo24_ml NaN count in original:', d.uo24_ml.isna().sum())
comp_pre = ['sofa_resp', 'sofa_coag', 'sofa_liver', 'sofa_cns', 'sofa_cardio_pre', 'sofa_renal_pre']
d['sofa_missing_pre_n'] = d[comp_pre].isna().sum(axis=1)
d['sofa_total_pre'] = d[comp_pre].fillna(0).sum(axis=1)

print('\nSOFA change (692):')
print(pd.crosstab(d.sofa_total, d.sofa_total_pre))
print('cardio changed:', (d.sofa_cardio != d.sofa_cardio_pre).sum(),
      ' renal changed:', (d.sofa_renal != d.sofa_renal_pre).sum(),
      ' total changed:', (d.sofa_total != d.sofa_total_pre).sum())
print('mean sofa_total old/new:', round(d.sofa_total.mean(), 2), round(d.sofa_total_pre.mean(), 2))
d.to_csv(REV / 'analysis' / 'cohort692_enhanced_v2.csv', index=False)

# ============ landmark (5456 stays; covers lm 868 and v3 1068) ============
lm = pd.read_csv(LM / 'lm_sofa.csv')
core = pd.read_csv(LM / 'lm_core.csv', parse_dates=['t0'])
pre2 = compute_pre(core[['stay_id', 't0']], LM / 'lm_outputevents.csv', LM / 'lm_inputevents.csv')
l = lm.merge(core[['stay_id', 't0']], on='stay_id', how='left').merge(pre2, on='stay_id', how='left')
l['sofa_cardio_pre'] = np.where(l.vaso_pre == 1, 3, np.where(l.inotrope_pre == 1, 2, 0))
l['sofa_renal_pre'] = np.maximum(l.cr_baseline.map(renal_cr), np.where(l.uo_pre24_ml < 500, 3, 0))
comp_pre_l = ['sofa_resp', 'sofa_coag', 'sofa_liver', 'sofa_cns', 'sofa_cardio_pre', 'sofa_renal_pre']
l['sofa_missing_pre_n'] = l[comp_pre_l].isna().sum(axis=1)
l['sofa_total_pre'] = l[comp_pre_l].fillna(0).sum(axis=1)
print('\nlandmark stays:', len(l), ' total changed:', (l.sofa_total != l.sofa_total_pre).sum(),
      ' mean old/new:', round(l.sofa_total.mean(), 2), round(l.sofa_total_pre.mean(), 2))
l.to_csv(LM / 'lm_sofa_pre.csv', index=False)

# validation of the fix on 692 subset vs old lm_sofa rules
sub = l[l.stay_id.isin(set(df.stay_id))]
print('lm_pre rows matching 692:', len(sub))
print('DONE')
